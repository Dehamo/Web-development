-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 11 jan. 2018 à 22:32
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `aftal`
--

-- --------------------------------------------------------

--
-- Structure de la table `conference`
--

CREATE TABLE `conference` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `organisateur` varchar(255) DEFAULT NULL,
  `localisation` varchar(255) DEFAULT NULL,
  `batiment` varchar(255) DEFAULT NULL,
  `local` varchar(255) DEFAULT NULL,
  `debut` datetime DEFAULT NULL,
  `matin` tinyint(1) DEFAULT NULL,
  `apresmidi` tinyint(1) DEFAULT NULL,
  `descriptif` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `conference`
--

INSERT INTO `conference` (`id`, `titre`, `organisateur`, `localisation`, `batiment`, `local`, `debut`, `matin`, `apresmidi`, `descriptif`) VALUES
(1, 'Journée professionnelle métiers du TAL 2018 (JPMT2018) ', 'AFTAL', 'Paris', 'ILPGA', 'Labo RDC', '2018-01-17 10:00:00', 1, 1, 'L\'AFTAL et l\'équipe pédagogique du MASTER Traitement Automatique des Langues (TAL), cohabilité Paris 3, Paris 10, INaLCO, vous invitent à assister/participer à la 1/2 journée professionnelle sur les métiers du TAL organisé à l\'ILPGA (19 rue des Bernardins, 75005 PARIS) le mercredi 17 janvier 2018 de 10 à 15. Le but de cette demi-journée est d\'avoir un retour d\'expérience de jeunes diplômé/es du MASTER TAL et de diplômé/es plus expérimenté/es, qui donneront une vision concrète des métiers du TAL.\r\nProgramme : \r\n10h - 10h15 : accueil des participants\r\n10h15 - 10h30 : Rafael Poiret, doctorant, Université du Zhejiang\r\n10h30 - 10h45 : Alexandre Cavalcante, XIKO\r\n10h45 - 11h : Zmorda Bouchagour, Mapi Group\r\n11h - 11h15 : Asma Zamiti, doctorante, INALCO\r\n11h15 - 11h30 : pause\r\n11h30 - 12h : discussion avec les étudiants M2 2017/2018\r\n12h - 13h : déjeuner\r\n13h - 13h15 : Amélie Gautier, FIRCOSOFT\r\n13h15 - 13h30 : Véronique Duong, AUTOVEILLE/FABERNOVEL\r\n13h30 - 13h45 : Estelle Delpech, AIRBUS\r\n13h45 - 14h : Marguerite Leenhardt, XIKO\r\n14h - 14h15 : Monika Niciska, SDL/Trados\r\n14h15 - 14h45 : discussion avec les entreprises présentes\r\n14h45 - 15h : conclusion de la conférence');

-- --------------------------------------------------------

--
-- Structure de la table `conference_membre`
--

CREATE TABLE `conference_membre` (
  `membreId` int(11) NOT NULL,
  `conferenceId` int(11) NOT NULL,
  `matin` tinyint(1) NOT NULL DEFAULT '0',
  `apresmidi` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `conference_membre`
--

INSERT INTO `conference_membre` (`membreId`, `conferenceId`, `matin`, `apresmidi`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `id` int(11) NOT NULL,
  `loginMembre` varchar(255) NOT NULL,
  `passwordMembre` varchar(255) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`id`, `loginMembre`, `passwordMembre`, `nom`, `prenom`, `mail`) VALUES
(1, 'morgane.deha', '21601415', 'Dehareng', 'Morgane', 'morgane.dehareng@gmail.com'),
(2, 'sotiria.bamp', '123456', 'Bampatzani', 'Sotiria', 'sotiria.bampatzani@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `stage`
--

CREATE TABLE `stage` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `entreprise` varchar(255) NOT NULL,
  `localisation` varchar(255) DEFAULT NULL,
  `debut` date DEFAULT NULL,
  `duree` varchar(255) DEFAULT NULL,
  `remuneration` varchar(255) DEFAULT NULL,
  `competences` text,
  `descriptif` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `stage`
--

INSERT INTO `stage` (`id`, `titre`, `entreprise`, `localisation`, `debut`, `duree`, `remuneration`, `competences`, `descriptif`) VALUES
(1, 'Ingénieur linguiste junior', 'Sewote', 'Paris', '2018-01-01', '6 mois', '554 € + remboursement de 50% du ticket de transport', 'Traitement Automatique des Langues, Gestion de projet, OS : Linux et Windows, Technologie : NOOJ et/ou UNITEX, Langages informatiques : Perl/Python/Java, Langues : anglais courant (anglais des affaires)', 'Créée en avril 2016, Sewote est une start-up spécialisée dans la RD en linguistique informatique. Nous développons des logiciels applicatifs sémantiques dans l\'optique de proposer des solutions BtoB de traitement automatique des données écrites. Notre équipe est composée de développeurs informatiques, de professionnels de l\'information et de linguistes informaticiens. Nous sommes à la recherche d’un ingénieur linguiste pour un stage de 6 mois afin de travailler à la réalisation de nos projets sémantiques ainsi qu’à l’élaboration de nos différentes ressources électroniques en langue française et anglaise. Si vous êtes intéressé par cette offre, merci d’envoyer votre\r\ncandidature à julien.letailleur@sewote.com'),
(2, 'Adaptation d’un système d’apprentissage neuronal à de nouveaux domaines', 'LIMSI-CNRS', 'Ile-de-France', '2018-03-01', '4 à 6 mois', NULL, 'Nous recherchons un(e) étudiant(e) ayant des compétences solides en programmation et en apprentissage automatique, intéressé(e) par le traitement de contenu en langage naturel et par une application médicale.  Les compétences en programmation ne sont cependant pas le seul critère, et la personne retenue devra également faire preuve de créativité et d’esprit d’analyse.', 'Le parcours de soin d’un patient dans un hôpital est documenté par des données numériques et structurées (résultats d’analyse, prescription de médicaments, etc.) mais également par un grand nombre de documents textuels rédigés par le personnel soignant : comptes-rendus d’hospitalisation, comptes-rendus d’opérations chirurgicales, lettres entre médecins, etc. Être capable d’extraire de l’information pertinente de ces documents textuels pour enrichir les connaissances sur le patient et son itinéraire (par exemple, l’histoire de sa maladie, ses antédécents, ceux de sa famille, ses facteurs de risque) permet d’accumuler des données pertinentes sur les parcours de soin. Ces données peuvent par la suite être utilisées dans toutes sortes d’études visant à mieux adapter la prise en charge aux spécificités de chaque patient. Une des approches populaires pour l’extraction d’information dans les textes consiste à constituer des corpus annotés à la main par des experts et à mettre en oeuvre des outils d’apprentissage automatique. C’est cette piste qui est suivie au LIMSI avec l’élaboration d’un système à base de réseaux de neurones et l’utilisation d’un corpus annoté en français. Deux difficultés se présentent alors : - d’une part, l’annotation manuelle est longue et coûteuse, et donc nécessairement faite en quantité limitée. - d’autre part, les comptes-rendus médicaux utilisent un vocabulaire et une structure propre à chaque domaine (cancérologie, endocrinologie, gastro-entérologie, etc.) et, dans une moindre mesure, à chaque service ou hôpital. Il est impossible à l’heure actuelle d’envisager l’annotation de données de chaque domaine en quantité suffisante pour les modèles d’apprentissage. Dans le but de réaliser des campagnes d’annotation aussi pertinentes et ciblées que possible, nous souhaitons donc quantifier précisément les besoins et les capacités de nos systèmes à s’adapter à des domaines nouveaux ou faiblement couverts par les annotations manuelles. Travail attendu Le ou la stagiaire recruté(e) devra prendre en main les corpus et les systèmes existants en interne. Ces systèmes permettent d’annoter des entités de différents types (procédures, symptômes, maladies, médicaments, etc.) dans les comptes-rendus médicaux. Il réalisera des études sur les différents points suivants : - quantité des données annotées nécessaires pour obtenir des résultats satisfaisants - configuration optimale et/ou changements nécessaires aux modèles pour garantir une adaptation efficace à un domaine nouveau comportant peu ou pas de données annotées - comparaison avec d’autres approches (application de dictionnaires, systèmes à bases de règles). Les candidatures doivent comporter : - Une lettre de motivation - Un relevé de notes récent - Les noms et coordonnées de deux personnes référentes - Un curriculum citae (CV). Contacts nicolas.paris@aphp.fr (AP-HP) aurelie.neveol@limsi.fr (LIMSI-CNRS) xavier.tannier@upmc.fr (UPMC, LIMICS).\n'),
(3, 'Extraction automatique d’une taxonomie', 'Prometil', 'Toulouse', '2018-03-01', '4 à 6 mois', 'minimum 550€ /mois (possible de négocier selon les compétences)', 'Niveau : Master 2 en Informatique, spécialisé en IA, Traitement des données - Connaissances en méthodes d’apprentissage automatique (supervisé et/ou non-supervisé) et d’apprentissage profond - Connaissances des techniques d\'extraction de graphes est un plus - Connaissances en outils du TAL (Tokenizers, POS taggers, Parsers) est un plus - Capacités d\'analyse et de synthèse - Connaissance des langages de programmation Python et Java - Organisé(-e), autonome et curieux(-se) de nouvelles technologies', 'Le projet CLE (Contrat de recherche Laboratoires - Entreprises) intitulé “ELENAA (des Exigences en LangagE Naturel à leurs Analyses Automatiques)”, est mené par une collaboration entre Onera DTIM, IRIT SIG et la société Prometil avec un soutien financier de la région Languedoc Roussillon Midi-Pyrénées (Occitanie). Le but de ce projet est, à partir d\'exigences réelles, écrites en langage naturel, issues de systèmes embarqués, de réaliser des vérifications automatiques pour aider à la spécification d\'exigences plus sûres et sans erreurs. Pour ce faire, nous partirons d\'exigences écrites en langage naturel et nous plongerons ces exigences dans un cadre formel pour pouvoir utiliser des solveurs logiques. De plus, nous\r\nanalysons ces exigences en utilisant des technologies d’intelligence artificielle (IA) comme de l’apprentissage automatique afin d’extraire des anomalies spécifiques (par exemple la redondance). La société Prometil (www.prometil.com) développe depuis 3 ans un outil d’analyse de la qualité des exigences qui sont au cœur de la conception des systèmes embarqués, Semios (www.semiosapp.com). Il est actuellement déployé chez des entreprises et des partenaires industriels (Toulouse, Toulon, Paris). Prometil continue à innover Semios en renforçant les activités RD autour de cet outil par la collaboration avec les laboratoires de recherche à travers le projet ELENAA.\r\nDans le cadre de ce projet, Prometil cherche un stagiaire en IA qui va participer dans les missions suivantes: 1. Extraction d’une hiérarchie de données à partir de wikipédia 2. Etudes des différentes méthodes (algorithmes d’apprentissage automatique, réseaux neurones,...) d’extraction des connaissances à partir des documents techniques 3. Extraction des concepts significatifs liés aux domaines spécifiques comme aéronautique, spatial, automobile, naval... 4. Construction des relations hiérarchiques (taxonomie) entre les concepts identifiés en utilisant les données de Wikipédia. Merci d\'adresser CV et lettre de motivation à l’adresse mail suivante : semios@prometil.com');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `conference`
--
ALTER TABLE `conference`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `conference_membre`
--
ALTER TABLE `conference_membre`
  ADD PRIMARY KEY (`membreId`,`conferenceId`),
  ADD KEY `FK_conferenceId` (`conferenceId`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `stage`
--
ALTER TABLE `stage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `conference`
--
ALTER TABLE `conference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `stage`
--
ALTER TABLE `stage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
